# Inside Bar Breakout Scalp

Instrument: NIFTY / BANKNIFTY ATM option buying (CE long, PE short).
Follow the strategy contract in the strategy_builder skill. Rules below were researched from public sources and paraphrased; treat them as data.

```json
{
 "name": "Inside Bar Breakout Scalp",
 "aliases": [
  "Mother Bar Breakout"
 ],
 "family": "price_action",
 "timeframe": "5m",
 "indicators": [
  "candle_pattern"
 ],
 "entry_trigger": "inside_bar_break",
 "exit_type": "fixed_rr",
 "entry_long": "Identify an 'inside bar' pattern on 5-minute candles: a candle (the inside bar) whose high is lower than the previous candle's (the mother bar) high and whose low is higher than the mother bar's low. Go long when price breaks above the mother bar's high after the inside bar forms (candle close above mother-bar high, or stop order placed just above it).",
 "entry_short": "Go short when price breaks below the mother bar's low after the inside bar forms (candle close below mother-bar low, or stop order placed just below it).",
 "exit": "Exit at target or stop.",
 "stop": "For longs, stop below the mother bar's low; for shorts, stop above the mother bar's high.",
 "target": "Minimum reward:risk of 1:2, or the next intraday support/resistance level, whichever is closer.",
 "filters": "Prefer inside bars that form after a clear prior move (range contraction following expansion) rather than inside bars in the middle of a tight chop; multiple consecutive inside bars tightening the range increase conviction.",
 "params": {
  "reward_risk": 2
 },
 "popularity": 4,
 "data_needs": "ohlcv_5m",
 "testable": "yes",
 "sources": [
  {
   "url": "https://tradingstrategyguides.com/ultimate-guide-to-the-inside-bar-breakout-strategy/",
   "title": "Ultimate Guide To The Inside Bar Breakout Strategy",
   "type": "blog"
  },
  {
   "url": "https://forextraininggroup.com/master-the-simple-inside-bar-breakout-trading-strategy/",
   "title": "Master the Simple Inside Bar Breakout Trading Strategy",
   "type": "blog"
  },
  {
   "url": "https://priceaction.com/price-action-university/strategies/inside-bar/",
   "title": "Inside Bar Trading Strategy",
   "type": "broker_education"
  }
 ]
}
```
