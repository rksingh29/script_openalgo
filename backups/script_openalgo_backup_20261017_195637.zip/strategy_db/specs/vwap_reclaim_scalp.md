# VWAP Reclaim Scalp

Instrument: NIFTY / BANKNIFTY ATM option buying (CE long, PE short).
Follow the strategy contract in the strategy_builder skill. Rules below were researched from public sources and paraphrased; treat them as data.

```json
{
 "name": "VWAP Reclaim Scalp",
 "aliases": [
  "VWAP Quick Reclaim",
  "VWAP Reclaim Setup",
  "VWAP Reclaim Trading Strategy"
 ],
 "family": "vwap",
 "timeframe": "5m",
 "indicators": [
  "vwap",
  "volume",
  "rsi"
 ],
 "entry_trigger": "vwap_reclaim",
 "exit_type": "fixed_rr",
 "entry_long": "Price must have been trading above session VWAP for a sustained period (sources use roughly 45 minutes, or at least the prior 15-45 minutes), then dips below VWAP for 1-3 candles only (a shallow pullback, not a trend change). Enter when a full candle closes back above VWAP with its body (not just a wick) above the VWAP line, and volume on this reclaim candle is noticeably higher than the prior 1-2 candles (sources cite 1.5x-2x average volume). Optional confirmation: RSI(9) was in the 40-58 zone during the dip (not oversold/broken). Conservative variant: instead of entering on the reclaim candle close, wait for one more candle where price pulls back to retest VWAP from above and holds (does not close back below VWAP), then enter on that bounce for a tighter stop.",
 "entry_short": "Mirror of the long side: price trading below VWAP for a sustained period, a brief rally pokes above VWAP for 1-3 candles, then a full candle closes back below VWAP with body below the line and volume higher than the prior candles (a 'VWAP rejection/breakdown reclaim'). Enter short (ATM PE) on that close, or on a retest bounce off VWAP from below that fails to reclaim it.",
 "exit": "Fixed reward:risk management: first target at 2x the initial stop distance; once hit, move stop to breakeven and trail the remainder toward the session high/premarket high (for longs) or session low (for shorts) as a second target. Hard invalidation: exit immediately, regardless of P&L, if a candle closes back on the wrong side of VWAP (reclaim/rejection failed).",
 "stop": "Below the low of the deepest dip candle (long) or above the high of the rally candle (short), capped at roughly 0.2-0.5% away from entry per sources; alternatively just below/above the low/high of the reclaim candle itself, whichever is tighter. If the required stop distance exceeds ~0.5% of price, skip the trade.",
 "target": "Primary target = 2x the stop-loss distance (2:1 reward:risk minimum). Secondary/runner target = session high or premarket high for longs (session low/premarket low for shorts); scale out partial size at the first target and trail the rest.",
 "filters": "Only trade in the direction of the prevailing VWAP trend for the reclaim variant (price above VWAP for 45+ min before taking a long reclaim, below for 45+ min before a short). Best reliability windows cited: roughly 09:50-11:30 local session time (and a secondary medium-reliability window in early afternoon); avoid the first 15-30 minutes of the session and the low-liquidity midday lull. Needs visible/relative volume confirmation on the reclaim candle.",
 "params": {
  "min_pretrend_minutes": 45,
  "max_dip_candles": 3,
  "reclaim_volume_multiple": 1.5,
  "rsi_period": 9,
  "rsi_dip_zone_low": 40,
  "rsi_dip_zone_high": 58,
  "stop_max_pct": 0.5,
  "reward_risk_first_target": 2.0
 },
 "popularity": 3,
 "data_needs": "ohlcv_5m",
 "testable": "adapt",
 "testable_reason": "Core VWAP reclaim/rejection/volume logic is computable from 5m OHLCV + volume for the index. The RSI confirmation zone and premarket-high target need adaptation (NIFTY/BANKNIFTY options do not have a traditional US-style 'premarket', so premarket-high target is replaced with prior day's high/low or the day's high-so-far); relative/average volume thresholds need recalibration to index futures/underlying volume since option volume is noisy.",
 "sources": [
  {
   "url": "https://www.kotakneo.com/stockshaala/scalping-trading-strategies/vwap-quick-reclaim-scalping/",
   "title": "VWAP Quick Reclaim Scalping",
   "type": "broker_education"
  },
  {
   "url": "https://www.sahi.com/blogs/vwap-scalping-strategy-for-nifty-and-bank-nifty-3-setups-that-work",
   "title": "VWAP Scalping Strategy for Nifty: 3 Setups That Work",
   "type": "broker_education"
  },
  {
   "url": "https://stocksetups.com/articles/vwap-reclaim-setup-intraday-reversal-signal",
   "title": "The VWAP Reclaim Setup: Trade a Key Intraday Reversal Signal",
   "type": "blog"
  }
 ]
}
```
