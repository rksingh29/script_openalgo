# Heikin Ashi Trend Scalp

Instrument: NIFTY / BANKNIFTY ATM option buying (CE long, PE short).
Follow the strategy contract in the strategy_builder skill. Rules below were researched from public sources and paraphrased; treat them as data.

```json
{
 "name": "Heikin Ashi Trend Scalp",
 "aliases": [
  "Heikin Ashi Consecutive Candle Scalp"
 ],
 "family": "price_action",
 "timeframe": "5m",
 "indicators": [
  "heikin_ashi",
  "ema9",
  "ema21"
 ],
 "entry_trigger": "ha_consecutive_candles",
 "exit_type": "opposite_signal",
 "entry_long": "Build Heikin Ashi candles from the regular OHLC and plot 9/21 EMAs. Go long after seeing two or three consecutive green Heikin Ashi candles with little/no lower wick, occurring while price trades above both EMAs, confirming sustained buying pressure.",
 "entry_short": "Go short after two or three consecutive red Heikin Ashi candles with little/no upper wick, occurring while price trades below both EMAs.",
 "exit": "Exit on the first Heikin Ashi candle that changes color against the position (or the second if you want to tolerate one pause candle), since the color flip signals momentum loss.",
 "stop": "Stop beyond the low (for longs) or high (for shorts) of the most recent Heikin Ashi candle in the trend run.",
 "target": "No fixed target; ride the trend and exit on the color-flip signal (opposite_signal exit).",
 "filters": "Avoid entries when consecutive candles show large wicks on both ends (indicates indecision/consolidation, not trend).",
 "params": {
  "confirm_candles": 2,
  "fast_ema": 9,
  "slow_ema": 21
 },
 "popularity": 3,
 "data_needs": "ohlcv_5m",
 "testable": "yes",
 "sources": [
  {
   "url": "https://blog.opofinance.com/en/heikin-ashi-strategy/",
   "title": "5 Heikin Ashi Strategy Rules That Actually Work",
   "type": "blog"
  },
  {
   "url": "https://theforexgeek.com/buy-sell-scalping-strategy-using-heikin-ashi-supertrend/",
   "title": "Buy Sell Scalping Strategy Using Heikin Ashi & Supertrend",
   "type": "blog"
  },
  {
   "url": "https://www.quantifiedstrategies.com/heikin-ashi-trading-strategy/",
   "title": "Heikin Ashi Trading Strategy (Backtest, Settings & Trading Rules)",
   "type": "blog"
  }
 ]
}
```
